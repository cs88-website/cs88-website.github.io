"""The hangman module implements the top level game logic for hangman."""
