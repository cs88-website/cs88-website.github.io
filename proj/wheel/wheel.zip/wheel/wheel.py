"""The wheel module implements the top level game logic for wheel of fortune."""
