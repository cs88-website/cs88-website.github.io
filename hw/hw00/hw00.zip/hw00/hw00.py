import webbrowser

webbrowser.open('https://bcourses.berkeley.edu/courses/1467723/quizzes/2275966')