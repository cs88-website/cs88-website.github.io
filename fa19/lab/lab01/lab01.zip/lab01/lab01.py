######################
# Required Questions #
######################

def temperature_converter(f_temp):
    """
    >>> temperature_converter(32)
    0.0
    """
    "*** YOUR CODE HERE ***"
    return celsius_temp


def pythagorean_triple(a,b,c):
    """
    >>> pythagorean_triple(3,4,5)
    True
    >>> pythagorean_triple(3,4,6)
    False
    """
    "*** YOUR CODE HERE ***"

