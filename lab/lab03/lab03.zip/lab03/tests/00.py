test = {
  'name': 'Question 1.1',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> from lab03 import *
          >>> fruitCart = [("apple", 0.5, 3), ("banana", 0.25, 4)]
          >>> tax(fruitCart, 10)
          a72332922e356240f60bb01be4bf2868
          # locked
          >>> calCart = [("oski", 1000, 1), ("go", 1.25, 2), ("bears", 3.5, 2)]
          >>> tax(calCart, 100)
          94e0bc7be18efc4f674f1fdfef0cb068
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}