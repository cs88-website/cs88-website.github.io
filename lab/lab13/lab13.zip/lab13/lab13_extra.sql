.read lab13.sql

-- Q7
CREATE TABLE smallest_int_count as
  -- REPLACE THIS LINE
  SELECT 'YOUR CODE HERE';

